//驗證是否為正確URL
function isURL(str) {
  var reg = /(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/;
  if (reg.test(str)) {
    return true;
  }
  return false;
}

function RedirectUrl(isIBMB, url, urlParams, dataLayer1, dataLayer2) {
  //取網址上的參數
  var AllVars = encodeURIComponent(location.search.substring(1));
  if (AllVars.trim().length > 0) {
    //去&符號(ex: campaigncode=1&sourcecode=2 )
    var Vars = AllVars.split("%26");
    for (var i = 0; i < Vars.length; i++) { // 這裡補上了 var 宣告，避免變數污染
      var value = Vars[i].toString();
      var str = Vars[i].split("%3D");//去符號=
      //只有campaigncode&sourcecode往後帶
      if (str[0].toLowerCase() == "campaigncode" || str[0].toLowerCase() == "sourcecode") {
        //判斷是否為IBMB,參數campaigncode轉campaign
        if (str[0].toLowerCase() == "campaigncode" && isIBMB == true) {
          value = "campaign%3D" + str[1].toString();
        }
        if (str[0].toLowerCase() == 'sourcecode' && isIBMB == true) {
          value = 'official%3D' + str[1].toString();
        }
        //往後帶的參數超過一個以上
        if (urlParams.length > 0) {
          urlParams += "%26" + value;
        } else {
          urlParams += value;
        }
      }
    }
  }
  //網址+參數
  if (urlParams.length > 0) {
    url += "%3F" + urlParams;
  }
  dataLayer.push({ event: dataLayer2 });
  
  // --- 以下為新增的白名單防護機制 (解決 Client DOM Open Redirect) ---
  var finalUrl = decodeURIComponent(url);
  var isTrusted = false;
  
  // 設定允許跳轉的白名單前綴（一定要加上結尾的斜線 / 以防範規避）
  var trustedPrefixes = [
      "https://www.o-bank.com/",
      "http://www.o-bank.com/",
      "/" // 允許相對路徑的站內跳轉
  ];

  for (var j = 0; j < trustedPrefixes.length; j++) {
      // 檢查網址是否以白名單中的可信前綴開頭
      if (finalUrl.indexOf(trustedPrefixes[j]) === 0) {
          isTrusted = true;
          break;
      }
  }

  // 驗證通過才允許重新導向
  if (isTrusted) {
      window.location.href = finalUrl;
  } else {
      console.error("安全機制攔截：未授權的重導向網址", finalUrl);
  }
  // -----------------------------------------------------------------
  
  return;
}